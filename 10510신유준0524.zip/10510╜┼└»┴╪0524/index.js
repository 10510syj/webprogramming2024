function drawTitle(){
    
let star = true;
for (let i=0; i<5; i++){
    for (let j=0; j<51; j++){
        if(i==2){
            document.write("<h1>선린 서비스</h1>");
            star =! star; 
            break;
        }
        else if(star){
            document.write("*");
        }
        else{
            document.write("&nbsp");
        }
        star =! star;
    }
    document.write("<br>");
}
}


//-------------------------본성적부----------------------------
const subject = ["국어", "영어", "수학","웹프"];


class Student{
    id;
    name;
    score;
    rank;
    constructor(id,name,score){
        this.id = id;
        this.name = name;
        this.score = score;
    }
    printScore(){
        document.write(`<h3>학번 : ${this.id}, 이름 : ${this.name}</h3>`);
        for (let i = 0; i<subject.length; i++){
            document.write(
                `${subject[i]} | ${this.score[i]} | ${this.getGrade(this.score[i])} <br>` 
            )
            }
    }
    getGrade(score){
        switch(parseInt(score/10)){
            case 10:
            case 9:
                return "A";
            case 8:
                return "B";
            case 7:
                return "C";
            default:
                return "F";
        }
    }
}
let Student1 = new Student(1,"김경원",[99,89,74,69]);
let Scoretable1 = new Scoretable();
table.studentList.push(student1);

//-------------선생이냐 학생이냐--------------
let isTeacher = confirm("얼유티처?");

if (isTeacher){
    table.drawTable()
;}
else{
    let studentid = prompt("학번을 입러ㅕㄱ하세요");
    if(parseInt(studentid) == Student1.id){
        Student1.printscore();
    }
}

class Scoretable { 
    studentList = [];
    drawTable(){
        document.write(this.studentList[0].id + " " + this.studentList[0].name);
        for (let i =0; i<this.studentList[0].score.length; i++){
            document.write(this.studentList[0],score[i] + "&nbsp")
        }
    }
}

//---------------총출력-------------
drawTitle();
Student1.printScore();